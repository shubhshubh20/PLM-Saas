package com.saas.plm.GptConnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GptConnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(GptConnectApplication.class, args);
	}

}
